package com.raidBots;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstTest {
    public ChromeDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "E:/chromedr/chromedriver.exe");
        driver = new ChromeDriver();
        System.out.println("Testing");
    }
        @Test
        public void FirstTest () {
            driver.get("https://www.raidbots.com/simbot/quick");
            String title = driver.getTitle();
            Assert.assertTrue(title.equals("Quick Sim - Raidbots"));
        }

        @Test
        public void FirstTest2() {
            driver.get("https://www.raidbots.com/simbot/talents");
            driver.findElement(By.id("app"));
        }
                @After
        public void close () {
            System.out.println("Testing is done");
            driver.quit();

        }
    }
